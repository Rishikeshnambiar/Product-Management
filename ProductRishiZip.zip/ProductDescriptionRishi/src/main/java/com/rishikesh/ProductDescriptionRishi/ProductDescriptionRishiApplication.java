package com.rishikesh.ProductDescriptionRishi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductDescriptionRishiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductDescriptionRishiApplication.class, args);
	}

}
