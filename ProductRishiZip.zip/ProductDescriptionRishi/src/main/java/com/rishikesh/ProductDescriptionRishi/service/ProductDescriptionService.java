package com.rishikesh.ProductDescriptionRishi.service;
import java.util.Optional;

import com.rishikesh.ProductDescriptionRishi.entity.ProductDescriptionEntity;



public interface ProductDescriptionService {

	public Optional<ProductDescriptionEntity> getById(Integer descId);
	public void addDescription(ProductDescriptionEntity description);
}

